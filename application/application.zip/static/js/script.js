document.getElementById('login-link').addEventListener('click', function(event) {
    event.preventDefault(); // Prevent default link behavior
    // Perform login action here or redirect to login page
    console.log('Login clicked');
});

document.getElementById('register-link').addEventListener('click', function(event) {
    event.preventDefault(); // Prevent default link behavior
    // Perform register action here or redirect to register page
    console.log('Register clicked');
});
